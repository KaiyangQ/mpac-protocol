========================================
  MPAC Collaborative Agent - Quick Start
========================================

This lets you join a collaborative coding session where multiple
AI agents (each operated by a different person) coordinate work
on shared code files using the MPAC protocol.


PREREQUISITES
-------------
- Python 3.9+
- An Anthropic API key (https://console.anthropic.com/settings/keys)


STEP 1: INSTALL
---------------
Open Terminal (Mac) or Command Prompt (Windows), go to this folder:

    cd mpac-starter-kit
    pip install mpac_protocol-0.1.1-py3-none-any.whl

If "pip" doesn't work, try "pip3".


STEP 2: RUN
-----------
    python run.py

First time it will ask you:
  - Coordinator address: the host person will send you this
    (looks like: ws://192.168.1.42:8766)
  - Your API key: starts with sk-ant-...
  - Your name: whatever you want

This gets saved to config.json so you only enter it once.


STEP 3: USE
-----------
Once connected, you'll see the shared workspace files:

    +------------------------------------------------------+
    | Workspace (3 files)                                  |
    +------------------------------------------------------+
    | auth.py            1765 bytes  sha256:76ad893bc...   |
    | api.py             1363 bytes  sha256:07d0460dc...   |
    | utils.py            918 bytes  sha256:e1c4bb95d...   |
    +------------------------------------------------------+

Commands:
    view auth.py                  - Read a file
    task Fix the bug in auth.py   - Give your agent a task
    quit                          - Leave the session

When you give a task:
  1. Your agent reads the file
  2. Calls Claude to generate a fix
  3. Shows you the diff (what changed)
  4. Commits to the shared workspace
  5. Other people's agents see your changes in real-time


WHAT YOU'LL SEE
---------------
  - Other agents joining/leaving the session
  - Real-time notifications when someone commits changes
  - Conflict warnings if two agents touch the same file
  - Color-coded diffs showing exactly what changed


TROUBLESHOOTING
---------------
"Cannot connect":
  - Make sure the host has started their coordinator
  - Check the address is correct (ask the host)
  - Make sure you're on the same WiFi, or use the ngrok address

"API key error":
  - Check your key at https://console.anthropic.com/settings/keys
  - Delete config.json and run again to re-enter it

"pip install fails":
  - Try: pip3 install mpac_protocol-0.1.1-py3-none-any.whl
  - Or: python -m pip install mpac_protocol-0.1.1-py3-none-any.whl
